package juegocartas;


public enum NombreCarta {
    AS,
    DOS,
    TRES,
    CUATRO,
    CINCO,
    SEIS,
    SIETE,
    OCHO,
    NUEVE,
    DIEZ,
    JACK,
    QUEEN,
    KING
}
